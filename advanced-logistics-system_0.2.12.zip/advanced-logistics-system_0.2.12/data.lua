require("styles.main")
require("prototypes.controller")

require("prototypes.technology")
